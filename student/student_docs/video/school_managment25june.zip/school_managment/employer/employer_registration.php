<html>
<head>
    <script type="text/javascript" src="../js/validation.js"></script>
    <link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#cmt").datepicker();
        });
    </script>
    <style>
    </style>
</head>

<body>
    <div class="main">
        <div class="employer-registration">
            <table border="2px solid black" style="width:99%;">
                <table border="2px solid black" style="width:50%;">
                    <form action="../classes/registration.php" method="post" enctype="multipart/form-data" name="employee_registration" onsubmit="return employee_registration_validitaion();">
                        <h1> Employer</h1>
                      
                        <tr><td style="width:250px;"><h3>Employer Registration Form</h3></td></tr>
                  <tr><td>Company Name</td><td><input type="text" name="company_name" id="company_name" required></td></tr>
    
 <tr><td>Comapny Address </td>
    
    <td><input type="text" name="company_address" id="company_address" style="height:120;width:99%;" rows="8" cols="30" required></td></tr>
 
   <tr><td> City </td>
    
    <td><input type="text" name="company_city" id="company_city" required></td></tr>
 
   <tr><td> Region </td>
    
    <td><input type="text" name="company_region" id="company_region" required></td></tr>
 
   <tr><td> Postal Code</td>
    
    <td><input type="text" name="company_postal_code" id="company_postal_code" required></td></tr>
    
    
<tr><td>First Name</td><td><select name="company_sir_title" id="company_sir_title">
    <option>Mrs</option>
    <option>Mr</option>
    <option>Miss</option>
    <option>Ms</option>
</select>
    <input type="text" name="company_f_name" id="company_f_name" placeholder="First Name" required></td>
</tr>
 
  <tr><td>Last Name </td>
    
    <td><input type="text" name="company_l_name" id="company_l_name" required></td></tr>
 
 <tr><td> Title  </td>
    
    <td><input type="text" name="company_title" id="company_title" required></td></tr>
 <tr><td> E-mail  </td>
    
    <td><input type="text" name="company_email" id="company_email" pattern="^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+"  required></td></tr>
 
 
 <tr><td> Telephone </td>
    <td><input type="text" name="company_telephone" id="company_telephone" required></td></tr>
    <tr><td> UserId </td>
    <td><input type="text" name="company_userid" id="company_userid" required></td></tr>
    <tr><td> Choose Password </td>
    
    <td><input type="password" name="company_password" id="company_password" required></td></tr>
    <tr><td> Repeat Password </td>
    
    <td><input type="password" name="company_rep_password" id="company_rep_password" required></td></tr>
    
    <tr><td><input type="checkbox" name="company_term" id="company_term"> I have read and agree to Work Taster's Terms & Conditions</td></tr>
                     <tr> <td> <input type="submit" name="employer" id="submit" value="Register"></td></tr> 
                 
                </form>
                </table>

                </table>

            </div>

        </div>

</body>

</html>