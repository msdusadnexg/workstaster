<html>
    <head>
        
    </head>
    
    <body>
        <form action="" method="post">
            <table border="2px solid black" style="width:90%;">
              <tr><td><h3>Create Vacancy</h3></td></tr>
               <tr><td>vacancy title</td><td><input type="text" name="vacanct_title" id="vacancy_title"></td></tr> 
                 <tr><td>Location</td><td>
                     <select name="location">
                         <option>Please Select</option>
                         <option>Solihull Branch</option>
                         <option>Worcester Branch</option>
                     </select>
                 </td></tr> 
                 <tr><td>Description</td><td><input type="text" name="description" id="description" style="width:90%"></td></tr> 
                
            </table>
            
            
        </form>
        
    </body>
    
</html>