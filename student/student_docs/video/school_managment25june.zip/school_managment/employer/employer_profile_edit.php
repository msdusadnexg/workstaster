 
<?php include('../classes/employer_fetched_data.php');
?>
<html>

<head>
    <script type="text/javascript" src="../js/validation.js"></script>
    <link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#cmt").datepicker();
        });
    </script>
    <style>
    </style>
</head>

<body>
    <div class="main">
        <div class="employer-registration">
            <table border="2px solid black" style="width:99%;">
                <table border="2px solid black" style="width:50%;">
                    <form action="../classes/employer_edit_save.php" method="post" enctype="multipart/form-data" name="employee_registration" onsubmit="return employee_registration_validitaion();">
                          <tr>
                        <td >
                            <h3>Employer Profile</h3>
                        </td>
                    </tr>

                    <tr>
                        <td>Comapany Name </td><td>
                            <INPUT TYPE="text" NAME="company_name" value="<?php echo $company_name ;?>">
                        </td>
                        </tr>
                        <tr>
                        <td>Company Address </td><td>
                        
                            <input type="text" ROWS="8" COLS="25" name="company_address" value="<?php echo $company_address;?>" style="height:110px;width:90%;"> 
                        </td>
                    </tr>
                        <tr>
                          <td>City</td><td>
                                    <input type="text" name="company_city" value="<?php echo $company_city;?>"> </td>
                            </tr>
                            <tr>
                        <td>Postal Code </td><td>
                            <input type="text" name="company_postal_code" value="<?php echo $company_postal_code;?>"> </td>
                    </tr>
                        <tr><td>Logo<br><br><img height="140" width="300" src="logo/<?php echo $logo;?>"></td>
                            
                        </tr>
                        <tr><td>Company Logo <input type="file" name="logo" id="logo"></td></tr>
                    <tr>
                        <td> Website </td><td>
                            <input type="text" name="company_website"  value="<?php echo $company_website;?>">
                        </td>
                    </tr>
                        
                          <tr>
                        <td>Main Telephone </td><td>
                            <input type="text" name="company_telephone"  value="<?php echo $company_telephone;?>"> </td>
                    </tr>
                    <tr><td><input type="submit" name="employer_edit" value="Save"></td><td><input type="submit" value="Cancel"></td></tr>
                 
                </form>
                </table>

                </table>

            </div>

        </div>

</body>

</html>