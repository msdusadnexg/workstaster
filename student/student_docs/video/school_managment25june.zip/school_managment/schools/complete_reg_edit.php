<?php include( '../classes/school_reg_fetched.php');?>
<form action="../classes/school_profile_complete.php" method="post" enctype="multipart/form-data">
    <table border="2px solid black">
        <tr>
            <td>
                <h3>School Registration Complete Detail</h3>
            </td>
        </tr>
        <tr>
            <td>Grade Level
                <td>
                    <input type="text" name="grade_level" id="grade_level" placeholder="Grade Level" value="<?php echo $grade_level ;?>" required>
                </td>
        </tr>
        <tr>
            <td> Number of Students </td>
            <td>
                <input type="text" name="num_student" id="num_student" placeholder="Number Of Studentts" value="<?php echo $number_of_student;?>" required>
            </td>
        </tr>
        <tr>
            <td> Number of Chaperones </td>
            <td>
                <input type="text" name="chaperones_name" id="chaperone_name" placeholder="Number of Chaperones " value="<?php echo $number_of_chaperones ;?>" required>
            </td>
        </tr>
        <tr>
            <td> Age Range </td>
            <td>
                <input type="text" name="age_range" id="age_range" placeholder="Age Range" value="<?php echo $age_range;?>" required>
            </td>
        </tr>
        <tr>
            <td>Special Needs</td>
            <td>
                <input type="text" name="sp_nees" id="sp_need" placeholder="Special Needs" value="<?php echo $special_needs ;?>" required>
            </td>
        </tr>
        <tr>
            <td> Special Needs Chaperones </td>
            <td>
                <select name="sp_need_chaperones" id="sp_need_chaperones" value="<?php echo $special_need_chaperones;?>">
                     <?php if($special_need_chaperones!==''){?>
      <option><?php echo $special_need_chaperones ;?></option>
      <?php }?>    
                    <option value="">- None -</option>
                    <option >1</option>
                    <option >2</option>
                    <option >3</option>
                    <option >4</option>
                    <option >5</option>
                    <option >6</option>
                    <option >7</option>
                    <option>8</option>
                    <option >9</option>
                    <option >10</option>
                </select>
            </td>
        </tr>

        <tr>
            <td>Day of Visit</td>
        </tr>
        <tr><td>1st Choice </td><td><input type=text name="first_choice" value="<?php echo $visit_date_first;?>"></td></tr>

        <tr>
            <td> 2nd Choice </td><td><input type=text name="second_choice" value="<?php echo $visit_date_second;?>"></td></td>
        </tr>

        <tr>
            <td> 3rd Choice </td><td><input type=text name="third_choise" value="<?php echo $visit_date_third;?>"></td>
            
        </tr>

        <tr>
            <td>Arrival Time</td><td><input type=text name="arr_time" value="<?php echo $arrival_time ;?>"></td>
           
        </tr>

        <tr>
            <td>Departure Time </td><td><input type=text name="dept_time" value="<?php echo $departure_time;?>"></td>
           
        </tr>

        <tr>
            <td>
                <input type="submit" name="complete_school_edit_save" value="Save" style="margin-left:200px;" />
            </td>
        </tr>
    </table>
</form>