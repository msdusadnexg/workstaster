<html>
    
    <head>
        <script type="text/javascript">
       function replace(hide1, hide, show ) {
  document.getElementById(hide).style.display="none";
document.getElementById(hide1).style.display="none";
  document.getElementById(show).style.display="block";
}
        
    </script>
    </head>
    <body>
        
        
        <h3>Login</h3>
        <button onclick="replace('employer','school','student');">Student</button> 
        <button   onclick="replace('student','school','employer');">Employer</button>
         <button   onclick="replace('student','employer','school');">School</button>
        <div  id="student" style="display:none;">
        <form action="classes/login.php" method="post">
            <h3>Student Login</h3>
            UserId <input type="text" name="student_id" id="student_id"><br>
             Password <input type="password" name="student_password" id="student_password"><br>
    <input type="submit" value="Login" name="student_login" > </form>
    <a href="student/student_registration.php">Signup</a><br>
            </div>
        <div id="employer" style="display:none;">
             <form action="classes/login.php" method="post">  
                  <h3>Employer Login</h3>
            UserId <input type="text" name="employer_id" id="employerid"><br>
             Password <input type="password" name="employer_password" id="employer_password"><br>
    <input type="submit" value="Login" name="employer_login"> </form>
    <a href="employer/employer_registration.php">Signup</a><br> 
        </div>
        
         <div id="school" style="display:none;">
             <form action="classes/login.php" method="post">  
                  <h3>School Login</h3>
            UserId <input type="text" name="school_id" id="school_id"><br>
             Password <input type="password" name="school_password" id="school_password"><br>
    <input type="submit" value="Login" name="school_login"> </form>
    <a href="schools/school_registration.php">Signup</a><br> 
        </div>
        
        
    </body>
</html>