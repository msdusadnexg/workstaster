-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 25, 2015 at 02:48 PM
-- Server version: 5.5.34
-- PHP Version: 5.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `workstarter`
--

-- --------------------------------------------------------

--
-- Table structure for table `employer_registration`
--

CREATE TABLE IF NOT EXISTS `employer_registration` (
  `company_userid` varchar(50) NOT NULL,
  `company_terms` varchar(10) NOT NULL,
  `company_first_name` varchar(200) NOT NULL,
  `company_last_name` varchar(200) NOT NULL,
  `company_email` varchar(100) NOT NULL,
  `company_name` varchar(500) NOT NULL,
  `company_address` varchar(5000) NOT NULL,
  `company_region` varchar(200) NOT NULL,
  `company_city` varchar(100) NOT NULL,
  `company_postal_code` varchar(20) NOT NULL,
  `company_telephone` varchar(20) NOT NULL,
  `company_title` varchar(250) NOT NULL,
  `company_website` varchar(100) NOT NULL,
  `logo` varchar(200) NOT NULL,
  UNIQUE KEY `userid` (`company_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employer_registration`
--

INSERT INTO `employer_registration` (`company_userid`, `company_terms`, `company_first_name`, `company_last_name`, `company_email`, `company_name`, `company_address`, `company_region`, `company_city`, `company_postal_code`, `company_telephone`, `company_title`, `company_website`, `logo`) VALUES
('mahendersinghdusad', 'checked', 'Mrs Nexg-Skills', 'Nexg-Skills', 'msdusad@gmail.com', 'Nexg-Skills', 'Nexg-Skills', 'Haryana', 'Nexg-Skills', '127310', '9991106434', 'Nexg-Skills', 'msdusad.uphero', 'comshu.png');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `userid` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `category` varchar(20) NOT NULL,
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`userid`, `password`, `email`, `category`) VALUES
('hh', '5e36941b3d856737e81516acd45edc50', 'hgj@g.com', 'School'),
('hjhgj', '5e36941b3d856737e81516acd45edc50', 'jhh@gmail.com', 'School'),
('mahender', 'b3cd915d758008bd19d0f2428fbb354a', 'msdusad@gmail.com', 'Student'),
('mahendersingh', '6f8f57715090da2632453988d9a1501b', 'msdusad@gmail.com', 'Student'),
('mahendersinghdusad', 'd41d8cd98f00b204e9800998ecf8427e', 'msdusad@gmail.com', 'Employer');

-- --------------------------------------------------------

--
-- Table structure for table `school_registration`
--

CREATE TABLE IF NOT EXISTS `school_registration` (
  `userid` varchar(50) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `school_name` varchar(500) NOT NULL,
  `address` varchar(5000) NOT NULL,
  `region` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `title` varchar(250) NOT NULL,
  `terms` varchar(10) NOT NULL,
  UNIQUE KEY `school_name` (`school_name`),
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_preferences`
--

CREATE TABLE IF NOT EXISTS `student_preferences` (
  `userid` varchar(50) NOT NULL,
  `all_jobs` varchar(8) NOT NULL,
  `banking_finance` varchar(8) NOT NULL,
  `retail` varchar(8) NOT NULL,
  `construction` varchar(8) NOT NULL,
  `legal` varchar(8) NOT NULL,
  `medical` varchar(8) NOT NULL,
  `other` varchar(8) NOT NULL,
  `newsletter` varchar(8) NOT NULL,
  `vacancies_distance` varchar(5) NOT NULL,
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_preferences`
--

INSERT INTO `student_preferences` (`userid`, `all_jobs`, `banking_finance`, `retail`, `construction`, `legal`, `medical`, `other`, `newsletter`, `vacancies_distance`) VALUES
('mahender', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
('mahendersingh', 'no', 'checked', 'checked', 'checked', 'checked', 'no', 'no', 'no', '20');

-- --------------------------------------------------------

--
-- Table structure for table `student_profile`
--

CREATE TABLE IF NOT EXISTS `student_profile` (
  `userid` varchar(50) NOT NULL,
  `home_address` varchar(1000) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `dob_day` varchar(2) NOT NULL,
  `dob_month` varchar(20) NOT NULL,
  `dob_year` varchar(10) NOT NULL,
  `t_c` tinyint(1) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `city` varchar(50) NOT NULL,
  `region` varchar(50) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `website` varchar(250) NOT NULL,
  `profile_picture` varchar(100) NOT NULL,
  `video` varchar(100) NOT NULL,
  `cv` varchar(100) NOT NULL,
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_profile`
--

INSERT INTO `student_profile` (`userid`, `home_address`, `phone`, `email`, `dob_day`, `dob_month`, `dob_year`, `t_c`, `first_name`, `last_name`, `gender`, `city`, `region`, `postal_code`, `website`, `profile_picture`, `video`, `cv`) VALUES
('mahender', 'Ramalwas', '9991106434', 'msdusad@gmail.com', '06', '', '', 0, 'Mahender', 'Singh', 'Select', 'Bhiwani', 'Haryana', '127310', 'msdusad.uphero.com', 'Alise.jpg', '', ''),
('mahendersingh', '', '', 'msdusad@gmail.com', '7', 'June', '2000', 1, 'maahi', 'dusad', 'Male', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_school`
--

CREATE TABLE IF NOT EXISTS `student_school` (
  `userid` varchar(50) NOT NULL,
  `school_name` varchar(300) NOT NULL,
  `school_address` varchar(2000) NOT NULL,
  `school_city` varchar(150) NOT NULL,
  `school_region` varchar(50) NOT NULL,
  `school_postalcode` varchar(20) NOT NULL,
  `school_contact_sr` varchar(20) NOT NULL,
  `school_contact_fname` varchar(100) NOT NULL,
  `school_contact_lname` varchar(100) NOT NULL,
  `school_phone` varchar(20) NOT NULL,
  `school_email` varchar(100) NOT NULL,
  `school_website` varchar(100) NOT NULL,
  UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_school`
--

INSERT INTO `student_school` (`userid`, `school_name`, `school_address`, `school_city`, `school_region`, `school_postalcode`, `school_contact_sr`, `school_contact_fname`, `school_contact_lname`, `school_phone`, `school_email`, `school_website`) VALUES
('mahendersingh', 'Nexg', 'Nexg', 'Nexg', 'Nexg', 'Nexg', 'Mrs', 'Nexg', 'Nexg', 'Nexg', 'Nexg@gmail.com', 'Nexg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
