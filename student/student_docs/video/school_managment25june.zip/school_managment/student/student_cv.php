<?php include( '../classes/student_fetched_data.php');?>
<html>

<head>
    <script type="text/javascript">
        function inscheck(checkvalue) {

            if (checkvalue == '0') {
                document.getElementById('gcses_id').style.display = 'none';
                document.getElementById('a-levels').style.display = 'none';
            }
            if (checkvalue == '1') {
                document.getElementById('gcses_id').style.display = 'block';
                document.getElementById('a-levels').style.display = 'none';
            }

            if (checkvalue == '2') {
                document.getElementById('a-levels').style.display = 'block';
                document.getElementById('gcses_id').style.display = 'none';
            }
             if (checkvalue == '3') {
                document.getElementById('a-levels').style.display = 'none';
                document.getElementById('gcses_id').style.display = 'none';
            }
        }
        function school_update(stautus){
            
            if (stautus=='0') {
                document.getElementById('new_school_same').style.display = 'none';
            }
        if (stautus=='1') {
                document.getElementById('new_school_same').style.display = 'none';
            }
            
            if (stautus=='2') {
                document.getElementById('new_school_same').style.display = 'block';
            }
        }
    </script>

</head>

<body>
    <table border="2px solid black" style="width:99%;">
        <table border="2px solid black" style="width:90%;">
            <h2>Student CV</h2>
            <form method="post" action="../classes/" name="registration_form" enctype="multipart/form-data">
                <tr>
                    <td>
                        <h3>Personal Information</h3>
                    </td>
                </tr>
                <tr>
                    <td>First Name </td>
                    <td>
                        <input type="text" name="first_name" id="first_name" value="<?php echo $first_name;?>">
                    </td>
                </tr>
                <tr>
                    <td>Last Name </td>
                    <td>
                        <input type="text" name="last_name" id="last_name" value="<?php echo $last_name;?>"> </td>
                </tr>
                <tr>
                    <td> E-mail </td>

                    <td>
                        <input type="text" name="email" id="email" pattern="^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+" value="<?php echo $email?>">
                    </td>
                </tr>
                <tr>
                    <td>Personal Website </td>
                    <td>
                        <input type="text" name="website" id="website" value="<?php echo $website;?>">
                    </td>
                </tr>

                <tr>
                    <td>Write Your CV
                        <input type="text" name="cv" id="cv" rows="200" cols="200" value="<?php echo $website;?>" style="height:400px;width:90%;">
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="submit" name="cv_personal">
                    </td>
                </tr>
            </form>

        </table>

        <table border="2px solid black" style="width:80%;">
            <form method="post" action="../classes/" name="registration_form" enctype="multipart/form-data">
                <tr>
                    <td>
                        <h3>Education Information</h3>
                    </td>
                </tr>
                <tr>
                    <td>School Name </td>
                    <td>
                        <INPUT TYPE="text" NAME="school_name" value="<?php echo $school_name ;?>">
                    </td>
                </tr>
                <tr>
                    <td>School Address </td>
                    <td>

                        <input type="text" ROWS="8" COLS="25" name="school_address" value="<?php echo $school_address;?>" style="height:110px;width:90%;">
                    </td>
                </tr>
                <tr>
                    <td>City</td>
                    <td>
                        <input type="text" name="school_city" value="<?php echo $school_city;?>"> </td>
                </tr>
                <tr>
                    <td>Region </td>
                    <td>
                        <input TYPE="text" NAME="school_region" value="<?php echo $school_region ;?>">
                    </td>
                </tr>

                <tr>


                    <td>Postal Code </td>
                    <td>
                        <input type="text" name="school_postalcode" value="<?php echo $school_postalcode;?>"> </td>
                </tr>
                <tr>
                    <td>when did you start school here?</td>

                    <td>
                        <select name="gcsc_school_start_month">
                            <option value="">Month</option>
                            <option>January</option>
                            <option>February</option>
                            <option>March</option>
                            <option>April</option>
                            <option>May</option>
                            <option>June</option>
                            <option>July</option>
                            <option>August</option>
                            <option>September</option>
                            <option>October</option>
                            <option>November</option>
                            <option>December</option>
                        </select>
                    </td>

                    <td>
                        <select name="gcsc_school_start_year">
                            <option value="">Year</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
                            <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                            <option value="1955">1955</option>
                            <option value="1954">1954</option>
                            <option value="1953">1953</option>
                            <option value="1952">1952</option>
                            <option value="1951">1951</option>
                            <option value="1950">1950</option>
                            <option value="1949">1949</option>
                            <option value="1948">1948</option>
                            <option value="1947">1947</option>
                            <option value="1946">1946</option>
                            <option value="1945">1945</option>
                            <option value="1944">1944</option>
                            <option value="1943">1943</option>
                            <option value="1942">1942</option>
                            <option value="1941">1941</option>
                            <option value="1940">1940</option>
                            <option value="1939">1939</option>
                            <option value="1938">1938</option>
                            <option value="1937">1937</option>
                            <option value="1936">1936</option>
                            <option value="1935">1935</option>
                            <option value="1934">1934</option>
                            <option value="1933">1933</option>
                            <option value="1932">1932</option>
                            <option value="1931">1931</option>
                            <option value="1930">1930</option>
                            <option value="1929">1929</option>
                            <option value="1928">1928</option>
                            <option value="1927">1927</option>
                            <option value="1926">1926</option>
                            <option value="1925">1925</option>
                            <option value="1924">1924</option>
                            <option value="1923">1923</option>
                            <option value="1922">1922</option>
                            <option value="1921">1921</option>
                            <option value="1920">1920</option>
                            <option value="1919">1919</option>
                            <option value="1918">1918</option>
                            <option value="1917">1917</option>
                            <option value="1916">1916</option>
                            <option value="1915">1915</option>
                            <option value="1914">1914</option>
                            <option value="1913">1913</option>
                            <option value="1912">1912</option>
                            <option value="1911">1911</option>
                            <option value="1910">1910</option>
                            <option value="1909">1909</option>
                            <option value="1908">1908</option>
                            <option value="1907">1907</option>
                            <option value="1906">1906</option>
                            <option value="1905">1905</option>
                            <option value="1904">1904</option>
                            <option value="1903">1903</option>
                            <option value="1902">1902</option>
                            <option value="1901">1901</option>
                            <option value="1900">1900</option>
                        </select>

                    </td>
                </tr>
                <tr>
                    <td>what are you currently studying towards (select one)?</td>

                    <td>
                        <select name="studying" id="studying" onchange="inscheck(this.value);">
                            <option value="0">Please Select</option>
                            <option value="1">GCSEs</option>
                            <option value="2">A-Levels</option>
                            <option value="3">BTEC</option>
                        </select>
                    </td>
                </tr>

                <div class="gcses" id="gcses_id" style="display:none;">
                    <tr>
                        <td>GCSE summary: you can give here a short explanation of why you have selected the GCSEs below (optional)
                            <br>
                            <input type="text" name="gcse_summary" id="gcse_summary" style="width:80%;" placeholder="GCSEs Summary">
                        </td>
                    </tr>
                    <table border="2px solid black" style="width:40%;">
                        <tr>
                            <td>Subjects(s) </td>
                            <td>Expected Grade(s)</td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject1" id="subject1" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade1" id="expected_grade1" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject2" id="subject2" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade2" id="expected_grade2" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject3" id="subject3" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade3" id="expected_grade3" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject4" id="subject4" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade4" id="expected_grade4" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject5" id="subject5" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade5" id="expected_grade5" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject6" id="subject6" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade6" id="expected_grade6" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject7" id="subject7" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade7" id="expected_grade7" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject8" id="subject8" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade8" id="expected_grade8" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject9" id="subject9" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade9" id="expected_grade9" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject10" id="subject10" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade10" id="expected_grade10" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject11" id="subject11" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade11" id="expected_grade11" placeholder="Expected Grade">
                            </td>
                        </tr>
                    </table>

                </div>
                <div class="a-levels" id="a-levels" style="display:none;">
                    <tr>
                        <td>A-Levels summary: you can give here a short explanation of why you have selected the A-Levels below (optional)
                            <br>
                            <input type="text" name="alevels_summary" id="alevels_summary" style="width:80%;" placeholder="A- Levels Summary">
                        </td>
                    </tr>
                    <table border="2px solid black" style="width:40%;">

                        <tr>
                            <td>Complete the table below providing information about the subject you will be taking and your expected grades</td>
                        </tr>
                        <tr>
                            <td>Subjects(s) </td>
                            <td>Expected Grade(s)</td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="alevel_subject1" id="alevel_subject1" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="alevel_expected_grade1" id="alevel_expected_grade1" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="alevel_subject2" id="alevel_subject2" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="alevel_expected_grade2" id="alevel_expected_grade2" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="alevel_subject3" id="alevel_subject3" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="alevel_expected_grade3" id="alevel_expected_grade3" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="alevel_subject4" id="alevel_subject4" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="alevel_expected_grade4" id="alevel_expected_grade4" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="alevel_subject5" id="alevel_subject5" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="alevel_expected_grade5" id="alevel_expected_grade5" placeholder="Expected Grade">
                            </td>
                        </tr>




                        <tr>
                            <td>GCSE Results: provide below the subjects and grades you have achieved for your GCSEs</td>
                        </tr>
                        <tr>
                            <td>Subjects(s) </td>
                            <td>Expected Grade(s)</td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject1" id="subject1" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade1" id="expected_grade1" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject2" id="subject2" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade2" id="expected_grade2" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject3" id="subject3" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade3" id="expected_grade3" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject4" id="subject4" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade4" id="expected_grade4" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject5" id="subject5" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade5" id="expected_grade5" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject6" id="subject6" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade6" id="expected_grade6" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject7" id="subject7" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade7" id="expected_grade7" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject8" id="subject8" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade8" id="expected_grade8" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject9" id="subject9" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade9" id="expected_grade9" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="subject10" id="subject10" placeholder="Subject">
                            </td>
                            <td>
                                <input type="text" name="expected_grade10" id="expected_grade10" placeholder="Expected Grade">
                            </td>
                        </tr>
                        <tr>
                            <td>Did you do your GCSEs at the same school?</td>

                            <td>
                                <select name="school_same" id="school_same" onchange="school_update(this.value);">
                                    <option value="0">Please Select</option>
                                    <option value="1">Yes</option>
                                    <option value="2">No</option>
                                </select>

                            </td>
                        </tr>
                        <div class="new_school_same" id="new_school_same" style="display:none;">
                            <tr>
                                <td>School Name </td>
                                <td>
                                    <INPUT TYPE="text" NAME="other_school_name" >
                                </td>
                            </tr>
                            <tr>
                                <td>School Address </td>
                                <td>

                                    <input type="text" ROWS="8" COLS="25" name="other_school_address"  style="height:110px;width:90%;">
                                </td>
                            </tr>
                            <tr>
                                <td>City</td>
                                <td>
                                    <input type="text" name="other_school_city"  </td>
                            </tr>
                            <tr>
                                <td>Region </td>
                                <td>
                                    <input TYPE="text" NAME="other_school_region" >
                                </td>
                            </tr>

                            <tr>


                                <td>Postal Code </td>
                                <td>
                                    <input type="text" name="other_school_postalcode"  </td>
                            </tr>
                            <tr>
                                <td>when did you start school here?</td>

                                <td>
                                    <select name="other_school_start_month">
                                        <option value="">Month</option>
                                        <option>January</option>
                                        <option>February</option>
                                        <option>March</option>
                                        <option>April</option>
                                        <option>May</option>
                                        <option>June</option>
                                        <option>July</option>
                                        <option>August</option>
                                        <option>September</option>
                                        <option>October</option>
                                        <option>November</option>
                                        <option>December</option>
                                    </select>
                                </td>

                                <td>
                                    <select name="other_school_start_year">
                                        <option value="">Year</option>
                                        <option value="2009">2009</option>
                                        <option value="2008">2008</option>
                                        <option value="2007">2007</option>
                                        <option value="2006">2006</option>
                                        <option value="2005">2005</option>
                                        <option value="2004">2004</option>
                                        <option value="2003">2003</option>
                                        <option value="2002">2002</option>
                                        <option value="2001">2001</option>
                                        <option value="2000">2000</option>
                                        <option value="1999">1999</option>
                                        <option value="1998">1998</option>
                                        <option value="1997">1997</option>
                                        <option value="1996">1996</option>
                                        <option value="1995">1995</option>
                                        <option value="1994">1994</option>
                                        <option value="1993">1993</option>
                                        <option value="1992">1992</option>
                                        <option value="1991">1991</option>
                                        <option value="1990">1990</option>
                                        <option value="1989">1989</option>
                                        <option value="1988">1988</option>
                                        <option value="1987">1987</option>
                                        <option value="1986">1986</option>
                                        <option value="1985">1985</option>
                                        <option value="1984">1984</option>
                                        <option value="1983">1983</option>
                                        <option value="1982">1982</option>
                                        <option value="1981">1981</option>
                                        <option value="1980">1980</option>
                                        <option value="1979">1979</option>
                                        <option value="1978">1978</option>
                                        <option value="1977">1977</option>
                                        <option value="1976">1976</option>
                                        <option value="1975">1975</option>
                                        <option value="1974">1974</option>
                                        <option value="1973">1973</option>
                                        <option value="1972">1972</option>
                                        <option value="1971">1971</option>
                                        <option value="1970">1970</option>
                                        <option value="1969">1969</option>
                                        <option value="1968">1968</option>
                                        <option value="1967">1967</option>
                                        <option value="1966">1966</option>
                                        <option value="1965">1965</option>
                                        <option value="1964">1964</option>
                                        <option value="1963">1963</option>
                                        <option value="1962">1962</option>
                                        <option value="1961">1961</option>
                                        <option value="1960">1960</option>
                                        <option value="1959">1959</option>
                                        <option value="1958">1958</option>
                                        <option value="1957">1957</option>
                                        <option value="1956">1956</option>
                                        <option value="1955">1955</option>
                                        <option value="1954">1954</option>
                                        <option value="1953">1953</option>
                                        <option value="1952">1952</option>
                                        <option value="1951">1951</option>
                                        <option value="1950">1950</option>
                                        <option value="1949">1949</option>
                                        <option value="1948">1948</option>
                                        <option value="1947">1947</option>
                                        <option value="1946">1946</option>
                                        <option value="1945">1945</option>
                                        <option value="1944">1944</option>
                                        <option value="1943">1943</option>
                                        <option value="1942">1942</option>
                                        <option value="1941">1941</option>
                                        <option value="1940">1940</option>
                                        <option value="1939">1939</option>
                                        <option value="1938">1938</option>
                                        <option value="1937">1937</option>
                                        <option value="1936">1936</option>
                                        <option value="1935">1935</option>
                                        <option value="1934">1934</option>
                                        <option value="1933">1933</option>
                                        <option value="1932">1932</option>
                                        <option value="1931">1931</option>
                                        <option value="1930">1930</option>
                                        <option value="1929">1929</option>
                                        <option value="1928">1928</option>
                                        <option value="1927">1927</option>
                                        <option value="1926">1926</option>
                                        <option value="1925">1925</option>
                                        <option value="1924">1924</option>
                                        <option value="1923">1923</option>
                                        <option value="1922">1922</option>
                                        <option value="1921">1921</option>
                                        <option value="1920">1920</option>
                                        <option value="1919">1919</option>
                                        <option value="1918">1918</option>
                                        <option value="1917">1917</option>
                                        <option value="1916">1916</option>
                                        <option value="1915">1915</option>
                                        <option value="1914">1914</option>
                                        <option value="1913">1913</option>
                                        <option value="1912">1912</option>
                                        <option value="1911">1911</option>
                                        <option value="1910">1910</option>
                                        <option value="1909">1909</option>
                                        <option value="1908">1908</option>
                                        <option value="1907">1907</option>
                                        <option value="1906">1906</option>
                                        <option value="1905">1905</option>
                                        <option value="1904">1904</option>
                                        <option value="1903">1903</option>
                                        <option value="1902">1902</option>
                                        <option value="1901">1901</option>
                                        <option value="1900">1900</option>
                                    </select>

                                </td>
                            </tr>
                            <tr>
                                <td>when did you leave this school?</td>

                                <td>
                                    <select name="other_school_start_month">
                                        <option value="">Month</option>
                                        <option>January</option>
                                        <option>February</option>
                                        <option>March</option>
                                        <option>April</option>
                                        <option>May</option>
                                        <option>June</option>
                                        <option>July</option>
                                        <option>August</option>
                                        <option>September</option>
                                        <option>October</option>
                                        <option>November</option>
                                        <option>December</option>
                                    </select>
                                </td>

                                <td>
                                    <select name="other_school_start_year">
                                        <option value="">Year</option>
                                        <option value="2009">2009</option>
                                        <option value="2008">2008</option>
                                        <option value="2007">2007</option>
                                        <option value="2006">2006</option>
                                        <option value="2005">2005</option>
                                        <option value="2004">2004</option>
                                        <option value="2003">2003</option>
                                        <option value="2002">2002</option>
                                        <option value="2001">2001</option>
                                        <option value="2000">2000</option>
                                        <option value="1999">1999</option>
                                        <option value="1998">1998</option>
                                        <option value="1997">1997</option>
                                        <option value="1996">1996</option>
                                        <option value="1995">1995</option>
                                        <option value="1994">1994</option>
                                        <option value="1993">1993</option>
                                        <option value="1992">1992</option>
                                        <option value="1991">1991</option>
                                        <option value="1990">1990</option>
                                        <option value="1989">1989</option>
                                        <option value="1988">1988</option>
                                        <option value="1987">1987</option>
                                        <option value="1986">1986</option>
                                        <option value="1985">1985</option>
                                        <option value="1984">1984</option>
                                        <option value="1983">1983</option>
                                        <option value="1982">1982</option>
                                        <option value="1981">1981</option>
                                        <option value="1980">1980</option>
                                        <option value="1979">1979</option>
                                        <option value="1978">1978</option>
                                        <option value="1977">1977</option>
                                        <option value="1976">1976</option>
                                        <option value="1975">1975</option>
                                        <option value="1974">1974</option>
                                        <option value="1973">1973</option>
                                        <option value="1972">1972</option>
                                        <option value="1971">1971</option>
                                        <option value="1970">1970</option>
                                        <option value="1969">1969</option>
                                        <option value="1968">1968</option>
                                        <option value="1967">1967</option>
                                        <option value="1966">1966</option>
                                        <option value="1965">1965</option>
                                        <option value="1964">1964</option>
                                        <option value="1963">1963</option>
                                        <option value="1962">1962</option>
                                        <option value="1961">1961</option>
                                        <option value="1960">1960</option>
                                        <option value="1959">1959</option>
                                        <option value="1958">1958</option>
                                        <option value="1957">1957</option>
                                        <option value="1956">1956</option>
                                        <option value="1955">1955</option>
                                        <option value="1954">1954</option>
                                        <option value="1953">1953</option>
                                        <option value="1952">1952</option>
                                        <option value="1951">1951</option>
                                        <option value="1950">1950</option>
                                        <option value="1949">1949</option>
                                        <option value="1948">1948</option>
                                        <option value="1947">1947</option>
                                        <option value="1946">1946</option>
                                        <option value="1945">1945</option>
                                        <option value="1944">1944</option>
                                        <option value="1943">1943</option>
                                        <option value="1942">1942</option>
                                        <option value="1941">1941</option>
                                        <option value="1940">1940</option>
                                        <option value="1939">1939</option>
                                        <option value="1938">1938</option>
                                        <option value="1937">1937</option>
                                        <option value="1936">1936</option>
                                        <option value="1935">1935</option>
                                        <option value="1934">1934</option>
                                        <option value="1933">1933</option>
                                        <option value="1932">1932</option>
                                        <option value="1931">1931</option>
                                        <option value="1930">1930</option>
                                        <option value="1929">1929</option>
                                        <option value="1928">1928</option>
                                        <option value="1927">1927</option>
                                        <option value="1926">1926</option>
                                        <option value="1925">1925</option>
                                        <option value="1924">1924</option>
                                        <option value="1923">1923</option>
                                        <option value="1922">1922</option>
                                        <option value="1921">1921</option>
                                        <option value="1920">1920</option>
                                        <option value="1919">1919</option>
                                        <option value="1918">1918</option>
                                        <option value="1917">1917</option>
                                        <option value="1916">1916</option>
                                        <option value="1915">1915</option>
                                        <option value="1914">1914</option>
                                        <option value="1913">1913</option>
                                        <option value="1912">1912</option>
                                        <option value="1911">1911</option>
                                        <option value="1910">1910</option>
                                        <option value="1909">1909</option>
                                        <option value="1908">1908</option>
                                        <option value="1907">1907</option>
                                        <option value="1906">1906</option>
                                        <option value="1905">1905</option>
                                        <option value="1904">1904</option>
                                        <option value="1903">1903</option>
                                        <option value="1902">1902</option>
                                        <option value="1901">1901</option>
                                        <option value="1900">1900</option>
                                    </select>

                                </td>
                            </tr>
                         
                        </div>
   </table>
                    
                </div>

                <tr>
                    <td>
                        <input type="submit" name="cv_education" value="Save">
                    </td>
                </tr>
            </form>

        </table>
        
        
     <table border="2px solid black" style="width:90%;">
           
            <form method="post" action="../classes/" name="registration_form" enctype="multipart/form-data">
                <tr>
                    <td>
                        <h3>Media</h3>
                    </td>
                </tr>
                <tr><td>Select A File</td><td><input type="file" name="video" id="video"></td></tr>
                <tr><td><input type="submit" name="video_upload" value="Upload" ></td></tr>
                </form>
         </table>
        
    </table>
</body>

</html>