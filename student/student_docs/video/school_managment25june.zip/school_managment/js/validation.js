function school_registration_validitaion(){

var em_pass = document.school_reg_form.password.value;
         var em_passcon = document.school_reg_form.rep_password.value;
            if (em_passcon != em_pass) {
                alert(" Re-Password Not Match");
                em_passcon.focus;
                return false;
            } 
}

function employee_registration_validitaion(){

var com_pass = document.employee_registration.company_password.value;
         var com_repass = document.employee_registration.company_rep_password.value;
            if (com_repass != com_pass) {
                alert(" Re-Password Not Match");
                com_repass.focus;
                return false;
            } 
}



function registration_valid(){


/* var em_name = document.registration_form.title.value;
            if (em_name == "") {
                alert(" Fill Title!");
               em_name.focus;
                return false;
            } 
            var dp = document.registration_form.name.value;
            if (dp == "") {
                alert("Please fill  Name ");
                dp.focus;
                return false;
            }
          
           
           
                   
     var em = document.registration_form.email.value;
            var s = "@";
            if (!em.match(s)) {
                alert("enter a valid email..");
                em.focus;
                return false;
            } 
    
    
    var rem = document.registration_form.re_email.value;
            if (em!=rem) {
                alert("Re Email Not Match ");
                em.focus;
                return false;
            }  
    
     var em_rg = document.registration_form.address.value;
            if ( em_rg == "") {
                alert(" Fill Address");
                em_rg.focus;
            return false;
               
            }
             
              var emss = document.registration_form.primery_tel.value;
            if (emss == "") {
                alert(" Fill Primary Telephone Number!");
                emss.focus;
                return false;
            } 
            
            var sq = document.registration_form.secrate_question.value;
            if (sq =="") {
                alert(" Please Choose Secret Question");
                sq.focus;
                return false;
            } 
    
    var sqa = document.registration_form.secrate_answer.value;
            if (sqa =="") {
                alert(" Fill Answer Secret Question");
                sqa.focus;
                return false;
            } 
    
        var dob = document.registration_form.dob.value;
            if (dob =="") {
                alert(" Fill date of Birth");
                dob.focus;
                return false;
            } 
            */
    
               
         var dpsm = document.registration_form.userid.value;
            if (dpsm == "") {
                alert(" Fill Userid");
                dpsm.focus;
                return false;
            } 
         var dpsmpp = document.registration_form.password.value;
            if (dpsmpp == "") {
                alert("Fill Password");
                dpsmpp.focus;
                return false;
            } 
         var dpsmss = document.registration_form.re_password.value;
            if (dpsmss != dpsmpp) {
                alert(" Re-Password Not Match");
                dpsmss.focus;
                return false;
            } 
    
    /*
    var captcha = document.registration_form.captcha_value.value;
    var captcha_insert = document.registration_form.captcha.value;
    
            if (captcha_insert !=captcha) {
                alert(" Wrong Captcha Inserted");
                captcha_insert.focus;
                return false;
            } 
            */
        
    }