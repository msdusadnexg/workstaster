<?php
include('connection.php');

class SchoolProfile {

 public function school_profile_complete(){

    $grade_lavel=$_POST['grade_level'];
    $numberof_student=$_POST['num_student'];
    $number_of_chaperones=$_POST['chaperones_name'];
    $age_range=$_POST['age_range'];
    $sp_needs=$_POST['sp_nees'];
    $sp_need_chaperones=$_POST['sp_need_chaperones'];
    $fm=$_POST['first_choice_month'];
    $fd=$_POST['first_choice_day'];
    $fy=$_POST['first_choice_year'];
    $sm=$_POST['second_choice_month'];
    $sd=$_POST['second_choice_day'];
    $sy=$_POST['second_choice_year'];
    $tm=$_POST['third_choice_month'];
    $td=$_POST['third_choice_day'];
    $ty=$_POST['third_choice_year'];
    $ath=$_POST['arrivial_time_hour'];
    $atm=$_POST['arrivial_time_minute'];
    $timestatus=$_POST['am'];
    $dth=$_POST['depart_time_hour'];
    $dtm=$_POST['depart_time_minute'];
    $secStatus=$_POST['secon_am'];
    $first_choise_date=$fd."/".$fm."/".$fy;
    $second_choise_date=$sd."/".$sm."/".$sy;
    $third_choise_date=$td."/".$tm."/".$ty;
    $depart_time=$dth." : ".$dtm."".$secStatus;
    $arrival_time=$ath." : ".$atm."".$timestatus;
    
    $Complete_school=mysql_query("update school_registration set grade_level='$grade_lavel',number_of_student='$numberof_student',number_of_chaperones='$number_of_chaperones',age_range='$age_range',special_needs='$sp_needs',special_need_chaperones='$sp_need_chaperones',visit_date_first='$first_choise_date',visit_date_second='$second_choise_date',visit_date_third='$third_choise_date',arrival_time='$arrival_time',departure_time='$depart_time';");
    
       
      if($Complete_school){
          echo '<script>alert("School Form Complete Detail Updated!");</script>';
        }
        else{
        
           echo '<script>alert("Error In School Form Complete Detail Updetation !'.mysql_error().'");</script>';
        }
}
    
  public function school_reg_edit_save(){
  $fname=$_POST['f_name'];
        $lname=$_POST['l_name'];
        $sc_email=$_POST['email'];
        $personal_tel=$_POST['telephone'];
        $tc_name=$_POST['trip_contact_name'];
        $tc_number=$_POST['trip_contact_cell_number'];
        $school_name=$_POST['school_name'];
        $street=$_POST['street'];
        $city=$_POST['city'];
        $state=$_POST['state'];
        $zip=$_POST['zip'];
        $school_tel_no=$_POST['tel_no'];
        $fax=$_POST['fax'];
        $country=$_POST['country'];
      
        $school_register_edit=mysql_query("update school_registration set first_name='$fname',last_name='$lname',email='$sc_email',personal_phone='$personal_tel',trip_contact_name='$tc_name',cell_number='$tc_number',school_name='$school_name',street='$street',city='$city',state='$state',zip='$zip',country='$country',telephone='$school_tel_no', fax='$fax';");
      
        if($school_register_edit){
         echo '<script>alert("School Registration Updated Sucessfully!");</script>';
        }
        else{
        echo '<script>alert("Error In School Detail Updatation !'.mysql_error().'");</script>';
        }
  
  }  
    
    public function School_Reg_Complete_EditSave(){
        
        $grade_lavel=$_POST['grade_level'];
    $numberof_student=$_POST['num_student'];
    $number_of_chaperones=$_POST['chaperones_name'];
    $age_range=$_POST['age_range'];
    $sp_needs=$_POST['sp_nees'];
    $sp_need_chaperones=$_POST['sp_need_chaperones'];
    $first_choise_date=$_POST['first_choice'];
    $second_choise_date=$_POST['second_choice'];
    $third_choise_date=$_POST['third_choise'];
    $depart_time=$_POST['arr_time'];
    $arrival_time=$_POST['dept_time'];
    
    $Complete_school=mysql_query("update school_registration set grade_level='$grade_lavel',number_of_student='$numberof_student',number_of_chaperones='$number_of_chaperones',age_range='$age_range',special_needs='$sp_needs',special_need_chaperones='$sp_need_chaperones',visit_date_first='$first_choise_date',visit_date_second='$second_choise_date',visit_date_third='$third_choise_date',arrival_time='$arrival_time',departure_time='$depart_time';");
    
    }
    
}

if(isset($_POST['complete_school_detail'])){

    $sc_pro_com= new SchoolProfile();
    $sc_pro_com->school_profile_complete();

}
if(isset($_POST['school_edit_save'])){

    $sc_pro_com= new SchoolProfile();
    $sc_pro_com->school_reg_edit_save();

}

if(isset($_POST['complete_school_edit_save'])){

    $sc_pro_com= new SchoolProfile();
    $sc_pro_com->School_Reg_Complete_EditSave();

}




?>