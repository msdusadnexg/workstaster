<?php
include('connection.php');

// Code for fetch data from database of employers table
$employer_detail=mysql_query("select * from employer_registration where company_userid='{$_SESSION['employeruserid']}';");
   if ($employer_detail){
 while($row = mysql_fetch_array($employer_detail)){
         $company_fname=$row['company_first_name'];
        $company_lname=$row['company_last_name'];
        $company_title=$row['company_title'];
        $company_email=$row['company_email'];
        $company_telephone=$row['company_telephone'];
        $company_name=$row['company_name'];
        $company_address=$row['company_address'];
        $company_city=$row['company_city'];
        $company_region=$row['company_region'];
        $company_postal_code=$row['company_postal_code'];
        $company_website=$row['company_website'];
     $logo=$row['logo'];
      } 
     
    }
        else{ echo '<script>alert("Employer Data Fetch Fetching Error!'.mysql_error().'");</script>';}

?>