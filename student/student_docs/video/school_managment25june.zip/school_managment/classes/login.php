<?php

include('connection.php');
class Login extends createConnection{

 public function StudentLogin(){

  $id=$_POST["student_id"];
$pass=$_POST["student_password"]; 
$pass=md5($pass);
$result=mysql_query("SELECT * FROM login WHERE userid='$id' && password='$pass' && category='Student';");
if ($result){
    
  if ($result && mysql_num_rows($result)>0) {
    if($row = mysql_fetch_array($result)){ 
       $_SESSION['studentuserid']=$row['userid'];
        $_SESSION['studentuserpass']=$row['password'];
       
        echo '<script>alert("Student Login Sucessfully!");</script>';
        echo '<script type="text/javascript">window.location ="../student/student_profile.php";</script>';
        //  echo '<META HTTP-EQUIV="Refresh" Content="0; URL=../student/student_profile.php">'; 
       //return header('Location:../student/student_profile.php');
    }
      
  }
   else{echo '<script>alert("NO Any Student User Found!'.mysql_error().'");</script>';}
}
    else{echo '<script>alert("Error IN Student Login Query!'.mysql_error().'");</script>';}
    
    

}
   public  function EmployerLogin(){
        $id=$_POST["employer_id"];
$pass=$_POST["employer_password"]; 
$pass=md5($pass);
$result=mysql_query("SELECT * FROM login WHERE company_userid='$id' && company_password='$pass' && category='Employer';");
if ($result){
    
  if ($result && mysql_num_rows($result)>0) {
    if($row = mysql_fetch_array($result)){ 
       $_SESSION['employeruserid']=$row['company_userid'];
        $_SESSION['employeruserpass']=$row['company_password'];
        echo '<script>alert("Employer Login Sucessfully!");</script>';
        echo '<script type="text/javascript">window.location ="../employer/employer_edit.php";</script>';
        //header('Location:../employer/employer_edit.php');
    }
      
  }
   else{echo '<script>alert("NO Any Employer User Found!'.mysql_error().'");</script>';}
}
    else{echo '<script>alert("Error IN Employer Login Query!'.mysql_error().'");</script>';}
    
    }
    
    
    
   public  function SchoolLogin(){
        $id=$_POST["school_id"];
$pass=$_POST["school_password"]; 
$pass=md5($pass);
$result=mysql_query("SELECT * FROM login WHERE userid='$id' && password='$pass' && category='School';");
if ($result){
    
  if ($result && mysql_num_rows($result)>0) {
    if($row = mysql_fetch_array($result)){ 
       $_SESSION['schooluserid']=$row['userid'];
        $_SESSION['schooluserpass']=$row['password'];
        echo '<script>alert("School Login Sucessfully!");</script>';
        echo '<script type="text/javascript">window.location ="../employer/employer_edit.php";</script>';
        //header('Location:../employer/employer_edit.php');
    }
      
  }
   else{echo '<script>alert("NO Any School User Found!'.mysql_error().'");</script>';}
}
    else{echo '<script>alert("Error IN School Login Query!'.mysql_error().'");</script>';}
    
    }
    
    
    
    

}

if(isset($_POST['student_login'])){
$log= new Login();
    $log->StudentLogin();
}
if(isset($_POST['employer_login'])){
$log= new Login();
    $log->EmployerLogin();
}

if(isset($_POST['school_login'])){
$log= new Login();
    $log->SchoolLogin();
}


?>