<?php
include('connection.php');
// Code for fetch data from database of school_registration table
$school_reg_fetch=mysql_query("select * from school_registration ;");
   if ($school_reg_fetch){
 while($row = mysql_fetch_array($school_reg_fetch)){
    $first_name=$row['first_name'];
     $last_name=$row['last_name'];
     $email=$row['email'];
     $personal_phone=$row['personal_phone'];
     $trip_contact_name=$row['trip_contact_name'];
     $cell_number=$row['cell_number'];
     $school_name=$row['school_name'];
     $street=$row['street'];
     $city=$row['city'];
     $state=$row['state'];
     $zip=$row['zip'];
     $country=$row['country'];
     $fax=$row['fax'];
     $telephone=$row['telephone'];
     $grade_level=$row['grade_level'];
     $number_of_student=$row['number_of_student'];
     $number_of_chaperones=$row['number_of_chaperones'];
     $age_range=$row['age_range'];
     $special_needs=$row['special_needs'];
     $special_need_chaperones=$row['special_need_chaperones'];
     $visit_date_first=$row['visit_date_first'];
     $visit_date_second=$row['visit_date_second'];
     $visit_date_third=$row['visit_date_third'];
     $arrival_time=$row['arrival_time'];
     $departure_time=$row['departure_time'];
     
      }
   }
else{ 
    echo '<script>alert("School Registration Fetch Data Query Pass Error !'.mysql_error().'");</script>';
    }

?>