<?php
include('connection.php');
class Registration extends createConnection{ // for insert data into database of registration 

   public  function student_regestration(){
          // for insert data into database
        $fname=$_POST['fname'];
       $lname=$_POST['lname'];
        $email=$_POST['email'];
        $userid=$_POST['userid'];
       $dob_day=$_POST['day'];
       $dob_month=$_POST['month'];
       $dob_year=$_POST['year'];
       $gender=$_POST['gender'];
        $password=$_POST['password'];
        $en_pass=md5($password);
        $category="Student";
         //$term_cond=$_POST['trm_cond'];
        if(!isset($_POST['trm_cond'])){ $term_cond="0";}
        else{$term_cond="1";}
       
        //for login table
         
        $login=mysql_query("insert into login (email,userid,password,category) values('$email','$userid','$en_pass','$category');");
         $student_school=mysql_query("insert into student_school (userid) values('$userid');");
         $student_preferences=mysql_query("insert into student_preferences (userid) values('$userid');");
         
        //for stdent profile table
        
        $student_profile=mysql_query("insert into student_profile (first_name,last_name,email,userid,dob_day,dob_month,dob_year,gender,t_c) values('$fname','$lname','$email','$userid','$dob_day','$dob_month','$dob_year','$gender','$term_cond');");
        
        
        if($student_profile){
            
             $_SESSION['studentuserid']=$_POST['userid'];
        $_SESSION['studentuserpass']=$_POST['password'];
              echo '<script type="text/javascript">window.location ="../student/student_profile.php";</script>';
          echo '<script>alert("Student Registration Sucessfully!");</script>';
        }
        else{
        
           echo '<script>alert("Error In Student Registration !'.mysql_error().'");</script>';
        }
    }
    
    // code for data insertion  employee registration
    
 public function employer_regestration(){

        $sir_title=$_POST['company_sir_title'];
        $company_fname=$sir_title." ".$_POST['company_f_name'];
        $company_lname=$_POST['company_l_name'];
        $company_title=$_POST['company_title'];
        $company_email=$_POST['company_email'];
        $company_telephone=$_POST['company_telephone'];
        $company_name=$_POST['company_name'];
        $company_address=$_POST['company_address'];
        $company_city=$_POST['company_city'];
        $company_region=$_POST['company_region'];
        $company_postal_code=$_POST['company_postal_code'];
        $company_userid=$_POST['company_userid'];
        $company_password=$_POST['company_password'];
        $company_pass=MD5($company_password);

        if(isset($_POST['company_term'])){
        $company_terms="checked";
        }
        else{ $company_terms="unchecked";}
    $company_categorytype="Employer";
    
  /*   $logo="../employer/logo/".$_FILES['Logo']['name'];
	move_uploaded_file($_FILES['Logo']['tmp_name'],$logo);
         $logoname=$_FILES['Logo']['name'];
         */
    
    
    $logindetail=mysql_query("insert into login (userid,password,email,category) values ('$company_userid','$company_pass','$company_email','$company_categorytype');");
        
        $employer_register=mysql_query("insert into employer_registration (company_userid,company_first_name,company_last_name,company_email,company_telephone,company_title,company_name,company_address,company_city,company_region,company_postal_code,company_terms) values('$company_userid','$company_fname','$company_lname','$company_email','$company_telephone','$company_title','$company_name','$company_address','$company_city','$company_region','$company_postal_code','$company_terms');");

 if($employer_register){
     
      $_SESSION['employeruserid']=$_POST['company_userid'];
        $_SESSION['employeruserpass']=$_POST['company_password'];
      echo '<script type="text/javascript">window.location ="../employer/employer_profile_edit.php";</script>';
          echo '<script>alert("Employer Registration Sucessfully!");</script>';

        }
        else{
        
           echo '<script>alert("Error In Employer Registration !'.mysql_error().'");</script>';
        }
    }
    
    
    public function school_registration(){
         $sir_title=$_POST['sir_title'];
        $fname=$sir_title." ".$_POST['f_name'];
        $lname=$_POST['l_name'];
        $title=$_POST['title'];
        $email=$_POST['email'];
        $telephone=$_POST['telephone'];
        $school_name=$_POST['school_name'];
        $address=$_POST['address'];
        $city=$_POST['city'];
        $region=$_POST['region'];
        $postal_code=$_POST['postal_code'];
        $userid=$_POST['userid'];
        $password=$_POST['password'];
        $pass=MD5($password);
        $categorytype="School";
        if(isset($_POST['term'])){
        $terms="checked";
        }
        else{ $terms="unchecked";}
        
        
        $logindetail=mysql_query("insert into login (userid,password,email,category) values ('$userid','$pass','$email','$categorytype');");
        
        $school_register=mysql_query("insert into school_registration (userid,first_name,last_name,email,telephone,title,school_name,address,city,region,postal_code,terms) values('$userid','$fname','$lname','$email','$telephone','$title','$school_name','$address','$city','$region','$postal_code','$terms');");
        
        if($school_register){
         echo '<script>alert("School Registration Sucessfully!");</script>';
 // echo '<script type="text/javascript">window.location ="../schools/complete_registration.php";</script>';
            
        }
        else{
        echo '<script>alert("Error In School Registration !'.mysql_error().'");</script>';
        }
    
    }
    
    

}

if(isset($_POST['student'])){
$cl= new Registration();
$cl->student_regestration();
}
if(isset($_POST['employer'])){
$cl= new Registration();
$cl->employer_regestration();
}
if(isset($_POST['school'])){
$cl= new Registration();
$cl->school_registration();
}

?>