<?php
class EmployerEdit{
  public   function employer_profile_edit(){
include('connection.php');
      
      
       $company_name=$_POST['company_name'];
        $company_address=$_POST['company_address'];
        $company_city=$_POST['company_city'];
        $company_postal_code=$_POST['company_postal_code'];
        $company_website=$_POST['company_website'];
        $company_telephone=$_POST['company_telephone'];
       
     $logo="../employer/logo/".$_FILES['logo']['name'];
	move_uploaded_file($_FILES['logo']['tmp_name'],$logo);
         $logoname=$_FILES['logo']['name'];
    
    
$employer_edit=mysql_query("update employer_registration set company_name='$company_name',company_address='$company_address',company_city='$company_city',company_telephone='$company_telephone',company_website='$company_website',company_postal_code='$company_postal_code',logo='$logoname';");

if($employer_edit){
echo '<script>alert("Employer Complete Profile Sucess!");</script>';
}
else{ echo '<script>alert("Employer profile Cometation Error!'.mysql_error().'");</script>';}
    }
}

if(isset($_POST['employer_edit'])){
$em_edit= new EmployerEdit();
    $em_edit->employer_profile_edit();

}

?>